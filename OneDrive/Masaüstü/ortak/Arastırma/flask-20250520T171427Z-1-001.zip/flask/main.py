from flask import Flask, request, jsonify
from ultralytics import YOLO
import os
from PIL import Image
import logging

app = Flask(__name__)

# Modeli yükle
MODEL_PATH = "C:/Users/Ogulcan/Desktop/isaretdili_yolo8/yolo8_trained_model.pt"
model = YOLO(MODEL_PATH)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Flask logger ayarı
logging.basicConfig(level=logging.DEBUG)

@app.route("/predict", methods=["POST"])
def predict():
    try:
        if "image" not in request.files:
            return jsonify({"error": "No image file provided"}), 400

        image_file = request.files["image"]

        if image_file.filename == "":
            return jsonify({"error": "No image file selected"}), 400

        # Resmi kaydet
        image_path = os.path.join(UPLOAD_FOLDER, image_file.filename)
        image_file.save(image_path)

        # Modeli çalıştır
        results = model.predict(source=image_path)
        predictions = []

        for result in results:
            for box in result.boxes:
                predictions.append({
                    "class": model.names[int(box.cls.item())],
                    "confidence": float(box.conf.item()),
                    "box": box.xyxy.tolist()[0],  # [xmin, ymin, xmax, ymax]
                })

        return jsonify({"predictions": predictions})

    except Exception as e:
        app.logger.error(f"Error during prediction: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/", methods=["GET"])
def home():
    return "YOLOv8 Flask API is running!", 200

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)